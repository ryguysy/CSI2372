/*Ex1b - a3 CSI2372A*/
// checks if a poker hand of 5 cards has at least one pair

#include <iostream>
using namespace std;

enum Color { club, diamond, spades, heart };
enum Face { seven, eight, nine, ten, jack, queen, king, ace };

struct Card
{
	Color color;
	Face face;
};

typedef Card Hand[5];

/* testPair() function*/
// takes a hand (array of 5 cards), returns true if two cards have the same face
bool testPair(const Hand& h)
{
	//YOUR CODE  
	// compare every card with the ones after it
	for (int i = 0; i < 5; i++) {
		for (int j = i + 1; j < 5; j++) {
			if (h[i].face == h[j].face)
				return true;
		}
	}
	return false;
}


/*Example of main()*/
int main()
{
	bool testPair(const Hand&);
	Hand myHand = { {club,nine}, {diamond, eight}, {spades, ace}, {spades, jack}, {club, ace} };
	cout << "\nI have at least: " << testPair(myHand) << " pair" << endl;
	return 0;
}



